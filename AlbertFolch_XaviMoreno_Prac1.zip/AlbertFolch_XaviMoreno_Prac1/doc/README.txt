Cada exercici conté un Makefile, només s'ha de fer un: 'make' o 'make amd'
